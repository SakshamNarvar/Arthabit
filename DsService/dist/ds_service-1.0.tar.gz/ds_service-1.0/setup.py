from setuptools import setup, find_packages

install_requires = [
    'Flask==3.0.3',
    'kafka-python==2.0.2',
    'langchain-core>=0.2.0',
    'langchain-google-genai>=1.0.3',
    'pydantic==2.7.1',
    'pydantic_core==2.18.2',
    'Pygments==2.17.2',
    'python-dateutil==2.9.0.post0',
    'python-dotenv==1.0.1',
]

setup(
    name='ds-service',
    version='1.0',
    packages=find_packages('src'),
    package_dir={'': 'src'},
    install_requires=install_requires,
    include_package_data=True,
)